using BepInEx;
using System.Reflection;

[assembly: AssemblyCompany("goldentrophy")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion(iiMenu.PluginInfo.Version + ".0")]
[assembly: AssemblyInformationalVersion(iiMenu.PluginInfo.Version)]
[assembly: AssemblyProduct(iiMenu.PluginInfo.Name)]
[assembly: AssemblyTitle(iiMenu.PluginInfo.Name)]
[assembly: AssemblyVersion(iiMenu.PluginInfo.Version + ".0")]
